/*
 *
 * Authentication constants
 *
 */

export const SET_AUTH = 'src/Authentication/SET_AUTH';
export const CLEAR_AUTH = 'src/Authentication/CLEAR_AUTH';
