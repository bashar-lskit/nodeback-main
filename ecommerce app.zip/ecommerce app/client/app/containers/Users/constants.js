/*
 *
 * Users constants
 *
 */

export const FETCH_USERS = 'src/Users/FETCH_USERS';
export const FETCH_SEARCHED_USERS = 'src/Users/FETCH_SEARCHED_USERS';
export const SET_ADVANCED_FILTERS = 'src/Users/SET_ADVANCED_FILTERS';
export const SET_USERS_LOADING = 'src/Users/SET_USERS_LOADING';
