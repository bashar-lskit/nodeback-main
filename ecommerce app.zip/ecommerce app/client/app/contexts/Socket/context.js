import React from 'react';

const SocketContext = React.createContext();

export default SocketContext;
